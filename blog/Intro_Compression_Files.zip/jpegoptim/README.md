
## Minimized

Minimized using jpegoptimizer with a setting of 1200k.

## default

jpegoptim's default lossless compressor.  You can get better results with [FileOptimizer](http://nikkhokkho.sourceforge.net/static.php?page=FileOptimizer)
