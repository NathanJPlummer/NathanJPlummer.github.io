## original

Original PNG file

## default

    guetzli ./original.png ./default.jpg

## default+progressive

Same as above but the run through lossy compressors using [FileOptimizer](http://nikkhokkho.sourceforge.net/static.php?page=FileOptimizer)

## Transparency

Note the loss of transparency during the JPG conversion
